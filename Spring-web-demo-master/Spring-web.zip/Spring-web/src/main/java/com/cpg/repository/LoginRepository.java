package com.cpg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cpg.entities.Login;

public interface LoginRepository extends JpaRepository<Login, Integer>{

}
