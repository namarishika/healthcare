package com.cpg.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cpg.repository.LoginRepository;
import com.cpg.repository.PatientRegistrationRepository;
import com.cpg.repository.UserRepository;
import com.cpg.entities.Login;
import com.cpg.entities.PatientRegistration;
import com.cpg.entities.User;
import com.cpg.exceptions.InvalidException;

@Service
public class LoginService {
	
	@Autowired
	LoginRepository loginRepository;
	
	@Autowired
	UserRepository userRepository;
	
	public String signIn(Login login) {
		//Optional<PatientRegistration> patientRegistration=patientRepository.findById(login.getUserId());
		
		Optional<User> user=userRepository.findById(login.getUserId());
		if(user.isEmpty()) {
			return "invalid id";
		}
		else {
			User user1=user.get();
			if(user1.isApprove()) {
			if(user1.getPassword().equals(login.getPassword())) {
			loginRepository.save(login);
			return "success";
			}
			else
				return "invalid password";
			}
			else
				return "User not approved";
		}
		
		
	}
	
	public Optional<Login> findById(int id) {
		return loginRepository.findById(id);
	}

	public Login signOut(int id) {
		Login login1=loginRepository.getOne(id);
		if(login1!=null) {
			loginRepository.deleteById(id);
		}
		return login1;
		
	}
	
	public Login changePassword(int id, String newpass) {
		Login login1=loginRepository.getOne(id);
		if(login1!=null) {
			User user=userRepository.getOne(id);
			login1.setPassword(newpass);
			user.setPassword(newpass);
			return loginRepository.save(login1);
		}
		return login1;
		
	}
	

}
