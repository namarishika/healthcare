package com.cpg.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cpg.entities.PatientRegistration;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface PatientRegistrationRepository extends JpaRepository<PatientRegistration, Integer> {

	@Query(value = "select * from patient where Date(created_at)=:d", nativeQuery = true)
	List<PatientRegistration> findByCreatedTime(@Param("d") LocalDate createdTime);
}
