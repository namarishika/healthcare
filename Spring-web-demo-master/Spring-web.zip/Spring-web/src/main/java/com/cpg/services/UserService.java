package com.cpg.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.entities.User;
import com.cpg.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;
	
	public User updateUser(int userId, User user) {
		User user1=userRepository.getOne(userId);
		BeanUtils.copyProperties(user, user1, "userId","approve");
		return userRepository.save(user1);
		
	}

	public User approve(int userId, User user) {
		// TODO Auto-generated method stub
		User user1=userRepository.getOne(userId);
		BeanUtils.copyProperties(user, user1, "userId", "name","age","gender","password","email","contactNumber","address","role");
		return userRepository.save(user1);
		
	}

}
