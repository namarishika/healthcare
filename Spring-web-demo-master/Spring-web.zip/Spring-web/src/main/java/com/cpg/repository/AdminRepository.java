package com.cpg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cpg.entities.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {

}
