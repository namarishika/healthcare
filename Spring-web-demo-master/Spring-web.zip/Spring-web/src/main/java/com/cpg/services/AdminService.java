package com.cpg.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.cpg.entities.Admin;
import com.cpg.repository.AdminRepository;

public class AdminService {
	
	@Autowired
	AdminRepository adminRepository;
	
	public Admin addPatient(Admin admin){
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
		
	}
	
	public void removeAdmin(int adminId){
		// TODO Auto-generated method stub
		adminRepository.deleteById(adminId);;
		
	}
	
	

	

}
