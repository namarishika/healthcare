package com.cpg.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cpg.entities.Login;
import com.cpg.exceptions.InvalidException;
import com.cpg.services.LoginService;

@RestController
public class LoginController {
	
	@Autowired
	LoginService service;
	
	@PostMapping("/login/add")
	public Login login(@RequestBody Login login) {
		Optional<Login> login1=service.findById(login.getUserId());
		String message;
		if(login1.isEmpty()) {
		message=service.signIn(login);
		if(message.equals("invalid password"))
			throw new InvalidException("Invalid Password");
		else if(message.equals("invalid id"))
			throw new InvalidException("Invalid Id");
		else if(message.equals("User not approved"))
			throw new InvalidException(message);
		return login;
		}
		else
			   throw new InvalidException("User already logged in");
		
	}
	
	@DeleteMapping("/login/remove/{id}")
	public ResponseEntity<String> logOut(@PathVariable int id) {
		Optional<Login> login1=service.findById(id);
		if(login1==null) {
			return new ResponseEntity<>("User is not logged in!!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		service.signOut(id);
		return new ResponseEntity<>("successfully signed out!!", HttpStatus.OK);
	}
	
	@PutMapping("/login/update/{id}")
	public Login updatePassword(@PathVariable int id,@RequestParam("newpassword") String newPassword) {
		return service.changePassword(id, newPassword);
	}
	
	@ExceptionHandler
	public String handleInvalidException(InvalidException exception) {
		return exception.getMessage();
	}

}
