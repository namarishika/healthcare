package com.cpg.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.entities.PatientRegistration;
import com.cpg.entities.User;
import com.cpg.repository.PatientRegistrationRepository;

@Service
public class PatientRegistrationService {
	@Autowired
	private PatientRegistrationRepository patientRepository; 
	


	public PatientRegistration addPatient(PatientRegistration patientRegistration){
		// TODO Auto-generated method stub
		return patientRepository.save(patientRegistration);
		
	}

	public PatientRegistration removePatient(int patientId){
		// TODO Auto-generated method stub
		patientRepository.deleteById(patientId);
		return null;
		
	}

	public PatientRegistration updatePatient(int patientId, PatientRegistration patientRegistration) {
		// TODO Auto-generated method stub
		PatientRegistration patientRegistration1=patientRepository.getOne(patientId);
		BeanUtils.copyProperties(patientRegistration, patientRegistration1,"patientId");
		return patientRepository.save(patientRegistration1);
	}

	public Optional<PatientRegistration> getPatient(int patientId){
		// TODO Auto-generated method stub
		return patientRepository.findById(patientId);
	}

	public List<PatientRegistration> getAllPatients(){
		// TODO Auto-generated method stub
		return patientRepository.findAll();
	}

	public List<PatientRegistration> getRegisteredPatientsByDates(LocalDate createdTime) {
		// TODO Auto-generated method stub
		return patientRepository.findByCreatedTime(createdTime);
	}

}
