package com.cpg.exceptions;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus
public class InvalidException extends RuntimeException {
	
	public InvalidException(String message) {
		super(message);
	}

}
